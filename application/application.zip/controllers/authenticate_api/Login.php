<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require APPPATH . '/libraries/REST_Controller.php';

class Login extends \Restserver\Libraries\REST_Controller {

	// load the constructor
	public function __construct() {

        parent::__construct();
        $this->load->model('users');

    }

	// load the register view
	public function index_get() {

		$this->load->view('login_view');

	}


	// login authetication the user
	 public function login_post() {

		$username = $this->input->post('username');
		$password = $this->input->post('password');

		if ($this->users->authenticate($username,$password)) {
			
			$this->session->is_logged_in = true;
			$this->session->username = $username;
			
			$this->set_response($username, \Restserver\Libraries\REST_Controller::HTTP_OK); // CREATED (200) being the HTTP response code
		}

		else {
			$this->session->login_error = True;
			
			$this->set_response($username, \Restserver\Libraries\REST_Controller::HTTP_UNAUTHORIZED); // CREATED (401) unauthorized to access the requested resource
		}
	}

	public function logout_get(){
        $this->session->sess_destroy();

		$res = "Session destroy successful";
		
		$this->set_response($res, \Restserver\Libraries\REST_Controller::HTTP_OK); // CREATED (200) being the HTTP response code
    }
}
