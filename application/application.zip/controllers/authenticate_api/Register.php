<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require_once APPPATH . '/libraries/REST_Controller.php';

class Register extends \Restserver\Libraries\REST_Controller {

	// load the constructor
	public function __construct() {

        parent::__construct();
        $this->load->model('users');

    }

	// load the register view
	public function index_get() {

		$this->load->view('register_view');

	}

	// register the user
	public function register_post() {

		$name = $this->input->post('name');

		$email = $this->input->post('email');

		$username = $this->input->post('username');

		$password = $this->input->post('password');
		
		if (!$this->users->registerUser($name, $email, $username, $password)) {

			$this->set_response($username, \Restserver\Libraries\REST_Controller::HTTP_NON_AUTHORITATIVE_INFORMATION); // CREATED (203) 

		}
		else {

			$this->set_response($username, \Restserver\Libraries\REST_Controller::HTTP_CREATED); // CREATED (201) being the HTTP response code

		}

	}

}
