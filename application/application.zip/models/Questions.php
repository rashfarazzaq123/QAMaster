<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Questions extends CI_Model {
    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }

    function questionPost($username, $title, $question, $topic_category){

        $user_id = $this->db->select('userID')->get_where('user', array('username' => $username))->result()[0]->userID;
       
        $questionID = mt_rand(1,999999);
        
        if ($title == null or $question  == null or $topic_category == null ) {
            return false;
        } else {
        
            if ($this->db->insert('Question',
        
            array('questionID' => $questionID, 'topic' => $title, 'content' => $question, 'keyword' => $topic_category, 'userId' => $user_id ,'upvoteQuestion' => 0, 'downVoteQuestion' => 0 ))){
                return True;
            }
            else {
                return False;
            }

        }
    
    }


    function questionGet($username){

        $user_id = $this->db->select('userID')->get_where('user', array('username' => $username))->result()[0]->userID;

        $response = $this->db->select('*')->get_where('question', array('userID' => $user_id))->result();

        return $response;

    }


    function allQuestionGet(){

        $response = $this->db->get('question')->result();

        return $response;

    }



    function questionDelete($question_id, $username){

        $user_id = $this->db->select('userID')->get_where('user', array('username' => $username))->result()[0]->userID;

        $query = "DELETE FROM question WHERE userID = $user_id AND questionID = $question_id";

        $response = $this->db->query($query);

        return $response;

    }

    function questionPut($username, $question_id, $updated_title, $updated_question, $updated_topic_category){

        $user_id = $this->db->select('userID')->get_where('user', array('username' => $username))->result()[0]->userID;

        $this->db->where(array('userID' => $user_id, 'questionID' => $question_id));

        if ($this->db->update('question', array('topic' => $updated_title, 'content' => $updated_question, 'keyword' => $updated_topic_category ))){
                return True;
            }
            else {
                return False;
            }

    }


    function answerPost($username, $question_id, $answer){

        $user_id = $this->db->select('userID')->get_where('user', array('username' => $username))->result()[0]->userID;
       
        $answer_id = mt_rand(1,999999);
        
        if ($question_id == null or $answer  == null) {
            
            return false;

        } else {
        
            if ($this->db->insert('Answer',
        
            array('answerID' => $answer_id, 'answer' => $answer, 'questionId' => $question_id, 'userID' => $user_id, 'upVoteAnswer' => 0, 'downVoteAnswer' => 0))){
                
                return True;
            }
            
            else {
                
                return False;
            }

        }
    
    }

    function answerDelete($answer_id, $username){

        $user_id = $this->db->select('userID')->get_where('user', array('username' => $username))->result()[0]->userID;

        $query = "DELETE FROM answer WHERE userID = $user_id AND answerID = $answer_id";

        $response = $this->db->query($query);

        return $response;

    }


    function answerPut($username, $answer_id, $updated_answer){

        $user_id = $this->db->select('userID')->get_where('user', array('username' => $username))->result()[0]->userID;

        $this->db->where(array('userID' => $user_id, 'answerID' => $answer_id));

        if ($this->db->update('answer', array('answer' => $updated_answer))){
                return True;
            }
            else {
                return False;
            }

    }

    function allAnswerGet(){

        $response = $this->db->get('answer')->result();

        return $response;

    }

    function votePut($isUpVote, $answer_id) {

        $upVoteCount = $this->db->select('upVoteAnswer')->get_where('answer', array('answerID' => $answer_id))->result()[0]->upVoteAnswer;

        $downVoteCount = $this->db->select('downVoteAnswer')->get_where('answer', array('answerID' => $answer_id))->result()[0]->downVoteAnswer;

        if ($isUpVote == true) {

            $upVoteCount = $upVoteCount + 1;

            $this->db->where(array('answerID' => $answer_id));
            
            if ($this->db->update('answer', array('upVoteAnswer' => $upVoteCount))){
                
                return True;
            }
            
            else {
                
                return False;
            }

        } else {

            $downVoteCount = $downVoteCount + 1;

            $this->db->where(array('answerID' => $answer_id));
            
            if ($this->db->update('answer', array('downVoteAnswer' => $downVoteCount))){
                
                return True;
            }
            
            else {
                
                return False;
            }

        }

    }

    function voteGet($isUpVote, $answer_id) {

        if ($isUpVote == true) {

            $upVoteCount = $this->db->select('upVoteAnswer')->get_where('answer', array('answerID' => $answer_id))->result();

            return $upVoteCount;

        } else {

            $downVoteCount = $this->db->select('downVoteAnswer')->get_where('answer', array('answerID' => $answer_id))->result();
        
            return $downVoteCount;
        }       

    }

    function searchQuestion($keyword) {

        $response = $this->db->select('*')->get_where('Question', array('keyword' => $keyword))->result();

        return $response;

    }

}